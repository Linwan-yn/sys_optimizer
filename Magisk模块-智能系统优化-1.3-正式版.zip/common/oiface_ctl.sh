#!/system/bin/sh
. /data/adb/modules/sys_optimizer_webui/common/functions.sh
oiface_ctl "$@"